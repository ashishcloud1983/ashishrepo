<?php
//*****************************************************************************
// Allow a new occurrence to be added to a database table.
//*****************************************************************************

//DebugBreak();
$table_id = 'crs_student';                      // table name
$screen   = 'crs_student.detail.screen.inc';    // file identifying screen structure

// require standard code
require 'std.add1.inc';

?>

<?php
//*****************************************************************************
// Allow a new occurrence to be added to a database table.
//*****************************************************************************

//DebugBreak();
$table_id = 'crs_schedule';                      // table name
$screen   = 'crs_schedule.detail.screen.inc';    // file identifying screen structure

// require standard code
require 'std.add2.inc';

?>

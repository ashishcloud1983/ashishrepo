<?php
// *****************************************************************************
// Update the contents of a database table without any dialog with the user.
// *****************************************************************************

$table_id = 'crs_conflict_s01';     // table name

//$result = ini_set('max_execution_time', '330');

require_once 'std.add4.inc';        // activate page controller

?>

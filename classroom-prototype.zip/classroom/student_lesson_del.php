<?php
//*****************************************************************************
// This will allow an occurrences of the STUDENT_LESSON table to be deleted.
// The identity of the selected occurrence is passed from the previous screen.
//*****************************************************************************

$table_id = 'crs_student_lesson';   // table name

require_once 'std.delete2.inc';     // activate page controller

?>


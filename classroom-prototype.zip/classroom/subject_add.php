<?php
//*****************************************************************************
// Allow a new occurrence to be added to a database table.
//*****************************************************************************

//DebugBreak();
$table_id = 'crs_subject';                     // table name
$screen   = 'crs_subject.detail.screen.inc';   // file identifying screen structure

require 'std.add1.inc';         // activate page controller

?>

<?php
// *****************************************************************************
// This will allow the user to choose a schedule_id from crs_schedule_hdr and
// store it in memory for use by other functions.
// *****************************************************************************

$table_id = 'crs_schedule_hdr_s01';         // table name

$popup_task = 'crs_schedule_hdr(popup)';  // name of popup

require 'std.update2.inc';                  // activate page controller

?>

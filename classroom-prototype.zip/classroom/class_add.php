<?php
//*****************************************************************************
// Allow a new occurrence to be added to a database table.
//*****************************************************************************

//DebugBreak();
$table_id = 'crs_class';                      // table name
$screen   = 'crs_class.detail.screen.inc';    // file identifying screen structure

// require standard code
require 'std.add1.inc';

?>

<?php
//*****************************************************************************
// This will allow an occurrences of the PERSON table to be deleted.
// The identity of the selected occurrence is passed down from the previous screen.
// NOTE: there is no dislog with the user.
//*****************************************************************************

$table_id = 'x_person';             // table id

require_once 'std.delete2.inc';     // activate page controller

?>

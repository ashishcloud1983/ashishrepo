<?php
//*****************************************************************************
// Allow a new occurrence to be added to the OPTION table.
//*****************************************************************************

//DebugBreak();
$table_id = 'x_option';         		// table name
$screen   = 'option.detail.screen.inc'; // file identifying screen structure

require 'std.add1.inc';                 // activate page controller

?>

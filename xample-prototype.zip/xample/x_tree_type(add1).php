<?php
//*****************************************************************************
// Allow a new occurrence to be added to the TREE_TYPE table.
//*****************************************************************************

//DebugBreak();
$table_id = 'x_tree_type';         	        // table name
$screen   = 'tree_type.detail.screen.inc';  // file identifying screen structure

require 'std.add1.inc';                     // activate page controller

?>

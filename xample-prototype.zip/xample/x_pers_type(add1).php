<?php
//*****************************************************************************
// Allow a new occurrence to be added to the PERS_TYPE table.
//*****************************************************************************

//DebugBreak();
$table_id = 'x_pers_type';         	        // table name
$screen   = 'pers_type.detail.screen.inc';  // file identifying screen structure

require 'std.add1.inc';                     // activate page controller

?>

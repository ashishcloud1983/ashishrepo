<?php
//*****************************************************************************
// Display help text for the specified task.
//*****************************************************************************

//$table_id = 'help_text';    // table id

// identify root folder for all help files
$root = "http://www.tonymarston.net/";

require 'std.help.inc';     // activate page controller

?>

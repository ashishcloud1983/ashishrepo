<?php
//*****************************************************************************
// This will allow an occurrences of the PERS_OPT_XREF table to be deleted.
// The identity of the selected occurrence is passed from the previous screen.
//*****************************************************************************

$table_id = 'x_pers_opt_xref';      // table name

require_once 'std.delete2.inc';     // activate page controller

?>


<?php
//*****************************************************************************
// Allow a new occurrence to be added to the TREE_LEVEL table for a particular
// value of TREE_TYPE_ID, as selected in the previous screen.
//*****************************************************************************

//DebugBreak();
$table_id = 'x_tree_level';				    // table name
$screen   = 'tree_level.detail.screen.inc'; // file identifying screen structure

require 'std.add2.inc';                     // activate page controller

?>

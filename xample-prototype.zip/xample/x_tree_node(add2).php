<?php
//*****************************************************************************
// Allow a new occurrence to be added to the TREE_NODE table for a particular
// value of TREE_TYPE_ID and TREE_TYPE_ID, as selected in the previous screen.
//*****************************************************************************

//DebugBreak();
$table_id = 'x_tree_node';				    // table name
$screen   = 'tree_node.detail.screen.inc';  // file identifying screen structure

require 'std.add2.inc';                     // activate page controller

?>

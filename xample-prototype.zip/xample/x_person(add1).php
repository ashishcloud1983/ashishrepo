<?php
//*****************************************************************************
// Allow a new occurrence to be added to the PERSON table.
//*****************************************************************************

//DebugBreak();
$table_id = 'x_person';					// table name
$screen   = 'person.detail.screen.inc'; // file identifying screen structure

require 'std.add1.inc';                 // activate page controller

?>

<?php
//*****************************************************************************
// Allow a new occurrence to be added to a database table.
//*****************************************************************************

//DebugBreak();
$table_id = 'test_autoincrement';         			// table name
$screen   = 'test_autoincrement.detail.screen.inc'; // file identifying screen structure

// activate page controller
require 'std.add1.inc';

?>

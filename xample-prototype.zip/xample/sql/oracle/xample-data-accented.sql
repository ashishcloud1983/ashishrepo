REPLACE INTO `x_option` VALUES ('C�TE', 'C�te d''Ivoire', '2006-08-26 08:57:09', 'AJM', NULL, NULL);
REPLACE INTO `x_option` VALUES ('HEFALUMP', 'El�ph�nt', '2006-08-26 08:57:09', 'AJM', NULL, NULL);
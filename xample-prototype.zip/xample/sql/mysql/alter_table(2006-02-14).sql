ALTER TABLE `x_person` CHANGE `node_id` `node_id` SMALLINT( 4 ) UNSIGNED NOT NULL DEFAULT '';
ALTER TABLE `x_person` CHANGE `pers_type_id` `pers_type_id` VARCHAR( 6 ) NOT NULL DEFAULT '';


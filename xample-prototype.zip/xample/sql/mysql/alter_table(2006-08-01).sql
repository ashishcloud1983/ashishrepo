ALTER TABLE `x_person` ADD `favourite_food` SET( '1', '2', '3', '4', '5', '6', '7', '8', '9', '10' ) NULL AFTER `picture` ;
ALTER TABLE `x_person` ADD `fckeditor_test` TEXT NULL AFTER `favourite_food` ;



<?php
//*****************************************************************************
// Extract the contents of a database table and export them to a CSV file which
// will be downloaded to the client device.
//*****************************************************************************

$table_id = 'x_person';         // table name

require 'std.output1.inc';      // activate page controller

?>

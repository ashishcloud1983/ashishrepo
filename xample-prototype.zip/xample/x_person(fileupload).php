<?php
//*****************************************************************************
// This will allow the user to upload a file to the server.
//*****************************************************************************

$table_id = 'x_person';                          // table id
$xsl_file = 'std.fileupload1.xsl';               // xsl file for transformation

require 'std.fileupload1.inc';                   // activate page controller

?>

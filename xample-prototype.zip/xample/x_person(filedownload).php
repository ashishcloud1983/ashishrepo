<?php
//*****************************************************************************
// This will allow the user to download a file to the server.
// The filename is obtained from a database record.
//*****************************************************************************

$table_id = "x_person_s01";                 // table name

require_once "std.filedownload1.inc";       // activate page controller
?>
